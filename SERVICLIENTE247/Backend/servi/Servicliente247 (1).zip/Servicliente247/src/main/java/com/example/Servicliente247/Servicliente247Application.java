package com.example.Servicliente247;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Servicliente247Application {

	public static void main(String[] args) {
		SpringApplication.run(Servicliente247Application.class, args);
	}

}
