package com.example.Servicliente247;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Servicliente247ApplicationTests {

	@Test
	void contextLoads() {
	}

}
